package com.lagou.edu.annotation;

import java.lang.annotation.*;

/**
 * @author: 李明
 * @create: 2020-03-13 17:13
 * @Description:
 */
@Documented
@Target({ElementType.CONSTRUCTOR,ElementType.METHOD,ElementType.FIELD,ElementType.PARAMETER,ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface TsComponent {
    String value() default "";
}
