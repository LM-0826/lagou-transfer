package com.lagou.edu.annotation;

import java.lang.annotation.*;

/**
 * @author: 李明
 * @create: 2020-03-13 17:14
 * @Description:
 */
@Documented
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface TsRepository {
    String value() default "";
}
